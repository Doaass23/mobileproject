<?php

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
require_once('connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve username and password from the POST data
    $username = isset($_POST['username']) ? addslashes(strip_tags($_POST['username'])) : '';
    $password = isset($_POST['password']) ? addslashes(strip_tags($_POST['password'])) : '';


    $sql = "SELECT Users.username, Users.password, Users.role FROM Users WHERE Users.username= '".$username."'";
	
	$result = mysqli_query($con, $sql);
	
	if ($result)
	{
		$emparray = array();
		while ($row = mysqli_fetch_assoc($result)) {
			$emparray[] = $row;
		}
		
		
		  if (count($emparray) > 0 && $emparray[0]['password'] === $password) {
		     // Password is correct
           // echo json_encode($emparray);
            $response= array('success' => true, 'data' => $emparray);
            
            //echo json_encode(array('success' => true, 'role' => $emparray[0]['role']));
        } else {
            // Invalid username or password
            //echo json_encode(array('error' => 'Invalid username or password'));
            
            //echo json_encode(array('success' => false, 'error' => 'Invalid username or password'));
            $response = array('success' => false, 'error' => 'Invalid username or password');
        }
		
		mysqli_free_result($result);
		
		}else{
			//echo json_encode(array('error' => 'Query execution failed'));
			//echo json_encode(array('success' => false, 'error' => 'Query execution failed'));
			$response = array('success' => false, 'error' => 'Query execution failed');
		}

		 mysqli_close($con);
} else {
    // No valid JSON data received
    //echo json_encode(array('success' => false, 'error' => 'No valid JSON data received'));
    $response = array('success' => false, 'error' => 'No valid JSON data received');
}

echo json_encode($response);
?>