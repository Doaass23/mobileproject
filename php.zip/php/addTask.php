addCategory.php

<?php
// Retrieve the raw POST data
$jsonData = file_get_contents('php://input');
// Decode the JSON data into a PHP associative array
$data = json_decode($jsonData, true);
// Check if decoding was successful
if ($data !== null) {
    $mid = addslashes(strip_tags($data['mid']));
    $eid = addslashes(strip_tags($data['eid']));
    $content = addslashes(strip_tags($data['content']));
    $DueDate = addslashes(strip_tags($data['DueDate']));
    



require_once('connect.php'); 

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql = "insert into Tasks (`task_id`, `manager_id`, `employee_id`, `content`, `due_date`, `status`)
        values (NULL, $mid, $eid, '$content', '$DueDate','pending')";
mysqli_query($con,$sql) or
    die ("can't add record");

echo "Record Added";
   
mysqli_close($con);
} else {
   // JSON decoding failed
   http_response_code(400); // Bad Request
   echo "Invalid JSON data";
}

?> 		