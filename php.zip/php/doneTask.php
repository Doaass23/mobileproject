addCategory.php

<?php
// Retrieve the raw POST data
$jsonData = file_get_contents('php://input');
// Decode the JSON data into a PHP associative array
$data = json_decode($jsonData, true);
// Check if decoding was successful
if ($data !== null) {
    $tid = addslashes(strip_tags($data['tid']));

require_once('connect.php'); 

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql = "UPDATE Tasks
SET status = 'completed'
WHERE task_id = '".$tid."' ";

mysqli_query($con,$sql) or
    die ("can't update status");

echo "Status Updated";
   
mysqli_close($con);
} else {
   // JSON decoding failed
   http_response_code(400); // Bad Request
   echo "Invalid JSON data";
}

?> 		